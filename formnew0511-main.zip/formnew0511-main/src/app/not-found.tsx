import type { FC } from 'react';

const NotFound: FC = () => {
    return <></>;
};

export default NotFound;
